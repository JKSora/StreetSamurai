from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password

# Create your models here.
class Categoria(models.Model):
    idCategoria = models.AutoField(primary_key=True)
    nombreCategoria = models.CharField(max_length=50)
    def __str__(self) -> str:
        return self.nombreCategoria
    
class Producto(models.Model):
    idProducto = models.AutoField(primary_key=True)
    nombreProducto = models.CharField(max_length=50)
    precioProducto = models.IntegerField()
    cantidadProducto = models.IntegerField()
    descripcionProducto = models.CharField(max_length=300)
    imagenProducto = models.ImageField(upload_to="")
    idCategoria = models.ForeignKey(Categoria,on_delete=models.CASCADE)
    def __str__(self) -> str:
        return self.nombreProducto
    
class Rol(models.Model):
    idRol = models.AutoField(primary_key=True)
    nombreRol = models.CharField(max_length=50)
    def __str__(self) -> str:
       return self.nombreRol

class Usuario(models.Model):
    idUsuario = models.AutoField(primary_key=True)
    nombreUsuario = models.CharField(max_length=80)
    correoUsuario = models.CharField(max_length=50)
    claveUsuario = models.CharField(max_length=18)
    nombrePerfil = models.CharField(max_length=50)
    apellidoPerfil = models.CharField(max_length=50)
    numeroPerfil = models.CharField(max_length=15)
    calleDireccion = models.CharField(max_length=50) 
    codigoPostal = models.IntegerField()
    paisDireccion = models.CharField(max_length=50)
    nombreRegion = models.CharField(max_length=80)
    idRol = models.ForeignKey(Rol,on_delete= models.DO_NOTHING)
    AdminUsuario = models.BooleanField(default=False)
    def __str__(self):
        return f'{self.idRol}  {self.idUsuario} {self.nombreUsuario}'
    def check_password(self, raw_password):
        return check_password(raw_password, self.claveUsuario)
        
class Carrito(models.Model):
    idUsuario = models.ForeignKey(User, on_delete=models.CASCADE)
    idProducto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidadCarrito = models.PositiveIntegerField(default=1)
    def __str__(self):
        return f"Carrito {self.idProducto} - Usuario: {self.idUsuario.username}"
    def total_price(self):
        total = self.cantidadCarrito * self.idProducto.precioProducto
        return total