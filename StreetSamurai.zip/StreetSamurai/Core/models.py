from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password

# Create your models here.
class Categoria(models.Model):
    idCategoria = models.AutoField(primary_key=True)
    nombreCategoria = models.CharField(max_length=50)
    def __str__(self) -> str:
        return self.nombreCategoria
    
class Producto(models.Model):
    idProducto = models.AutoField(primary_key=True)
    nombreProducto = models.CharField(max_length=50)
    precioProducto = models.IntegerField()
    cantidadProducto = models.IntegerField()
    descripcionProducto = models.CharField(max_length=300)
    categoria = models.ForeignKey(Categoria,on_delete=models.CASCADE)
    foto = models.ImageField(upload_to="Media")
    def __str__(self) -> str:
        return self.nombreProducto
    
class Rol(models.Model):
    idRol = models.AutoField(primary_key=True)
    nombreRol = models.CharField(max_length=50)
    def __str__(self) -> str:
       return self.nombreRol

class Usuario(models.Model):
    idUsuario = models.AutoField(primary_key=True)
    nombreUsuario = models.CharField(max_length=80)
    correoUsuario = models.CharField(max_length=50)
    claveUsuario = models.CharField(max_length=18)
    idRol = models.ForeignKey(Rol,on_delete= models.DO_NOTHING)
    AdminUsuario = models.BooleanField(default=False)
    def __str__(self):
        return f'{self.idRol}  {self.idUsuario} {self.nombreUsuario}'
    def check_password(self, raw_password):
        return check_password(raw_password, self.claveUsuario)

class Region(models.Model):
    idRegion = models.AutoField(primary_key=True)
    nombreRegion = models.CharField(max_length=80)
    def __str__(self) -> str:
       return self.nombreRegion

class Comuna(models.Model):
    idComuna = models.AutoField(primary_key=True)
    nombreComuna = models.CharField(max_length=80)   
    region = models.ForeignKey(Region,on_delete=models.DO_NOTHING) 
    costoDespacho = models.IntegerField()
    def __str__(self) -> str:
       return self.nombreComuna

class Direccion(models.Model):
    idDireccion = models.AutoField(primary_key=True)
    calleDireccion = models.CharField(max_length=50) 
    codigoPostal = models.IntegerField()
    paisDireccion = models.CharField(max_length=50)
    comuna = models.ForeignKey(Comuna,on_delete=models.DO_NOTHING)
    usuario = models.ForeignKey(Usuario,on_delete=models.DO_NOTHING)
    def __str__(self) -> str:
       return self.usuario + self.calleDireccion # type: ignore
    
class PerfilUsuario(models.Model):
    idPerfil = models.AutoField(primary_key=True)
    nombrePerfil = models.CharField(max_length=50)
    apellidoPerfil = models.CharField(max_length=50)
    numeroPerfil = models.CharField(max_length=15)
    direccion = models.ForeignKey(Direccion,on_delete=models.DO_NOTHING)
    comuna = models.ForeignKey(Comuna,on_delete=models.DO_NOTHING)
    adicionalPerfil = models.CharField(max_length=300)
    def __str__(self) -> str:
        return self.nombrePerfil

class Compra(models.Model):
    idCompra = models.AutoField(primary_key=True)
    fechaCompra = models.DateField()
    usuario = models.ForeignKey(Usuario, on_delete=models.DO_NOTHING)
    totalCompra = models.IntegerField()
    direccion = models.ForeignKey(Direccion, on_delete= models.DO_NOTHING)
    def __str__(self):
        return f'{self.idCompra} {self.usuario} {self.totalCompra}'
        
class Carrito(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, null=True, blank=True)
    cantidadCarrito = models.PositiveIntegerField(default=1)
    fechaCarrito = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"Carrito {self.producto} - Usuario: {self.usuario.username}"