from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth import get_user
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
from .models import *
from django.http import Http404
from django.contrib.auth.models import User

# Create your views here.
def Main(request):
    return render(request,'Core/Main.html')

def Store(request):
    listaP = Producto.objects.all()
    contexto = {"productos": listaP}
    return render(request,'Core/Store.html', contexto)

def AboutUs(request):
    return render(request,'Core/AboutUs.html')

def AddItems(request):
    return render(request,'Core/AddItems.html')

def ModItems(request):
    return render(request,'Core/ModItems.html')

@login_required
def ALTStore(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        listaP = Producto.objects.all()
        contexto = {"productos": listaP}
        return render(request,'Core/ALTStore.html', contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def modificarP(request, id):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        producto = Producto.objects.get(idProducto=id)
        categoria = Categoria.objects.all()
        contexto = {"datos": producto, "categoria": categoria}
        return render(request, "Core/ModItems.html", contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def eliminarP(request, id):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):    
        producto = Producto.objects.get(idProducto=id)
        producto.delete()
        messages.success(request, "Producto eliminado correctamente")
        return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def agregar(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        categoria = Categoria.objects.all()
        contexto = {"listaCategoria": categoria}
        return render(request, "Core/AddItems.html", contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def insertarProducto(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        nombreP = request.POST["v_name"]
        descripcionP = request.POST["v_description"]
        fotoP = request.FILES["v_image"]
        precioP = request.POST["v_price"]
        stockP = request.POST["v_cuantity"]
        categoriaP = request.POST["v_category"]

        registroCategoria = Categoria.objects.get(idCategoria=categoriaP)
        Producto.objects.create(
            nombre=nombreP,
            descripcion=descripcionP,
            imagen=fotoP,
            precio=precioP,
            stock=stockP,
            idCategoria=registroCategoria,
        )
        return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def actualizarP(request):
    idP = request.POST.get("idp")
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        if idP:
            producto = Producto.objects.get(idProducto=idP)
            nombreP = request.POST.get("v_name")
            descripcionP = request.POST.get("v_description")
            precioP = request.POST.get("v_price")
            stockP = request.POST.get("v_cuantity")
            categoriaP = request.POST.get("v_category")

            if request.FILES.get('v_image'):
                producto.foto = request.FILES.get('v_image')
            else:
                producto.foto = producto.foto # type: ignore

            producto.nombreProducto = nombreP
            producto.descripcionProducto = descripcionP
            producto.precioProducto = precioP
            producto.cantidadProducto = stockP
            registroCategoria = Categoria.objects.get(idCategoria=categoriaP)
            producto.categoria = registroCategoria
            producto.save()
            messages.success(request, "Producto modificado correctamente")
            return redirect("ALTStore")

        else:
            messages.error(request, "No se proporcionó un ID de producto válido")
            return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")

def ContactUs(request):
    return render(request,'Core/ContactUs.html')

def ForgotPassword(request):
    return render(request,'Core/ForgotPassword.html')

def Hoodie(request):
    return render(request,'Core/Hoodie.html')

def Hoodie2(request):
    return render(request,'Core/Hoodie2.html')

def HTSneakers(request):
    return render(request,'Core/HTSneakers.html')

def Login(request):
    return render(request,'Core/Login.html')

def ProfileSettings(request):
    return render(request,'Core/ProfileSettings.html')

def PurchaseStatus(request):
    return render(request,'Core/PurchaseStatus.html')

def ShoppingCart(request):
    return render(request,'Core/ShoppingCart.html')

def ShoppingCartFULL(request):
    return render(request,'Core/ShoppingCartFULL.html')

def SignUp(request):
    return render(request,'Core/SignUp.html')

def StreetwearPants(request):
    return render(request,'Core/StreetwearPants.html')

def TermsofService(request):
    return render(request,'Core/TermsofService.html')

def iniciar_sesion(request):
    usuario1 = request.POST["v_email"]
    contra1 = request.POST["v_psw"]
    try:
        user1 = User.objects.get(username=usuario1)
    except User.DoesNotExist:
        messages.error(request, "El usuario o la contraseña son incorrectos")
        return redirect("Login")
    pass_valida = check_password(contra1, user1.password)
    if not pass_valida:
        messages.error(request, "El usuario o la contraseña son incorrectos")
        return redirect("Login")
    usuario2 = Usuario.objects.get(correo=usuario1, clave=contra1)
    user = authenticate(username=usuario1, password=contra1)
    if user is not None:
        login(request, user)
        if usuario2.idRol == 1:
            return redirect("ALTStore")
        else:
            contexto = {"usuario": usuario2}
            return render(request, "Core/Main.html", contexto)

def cerrar_sesion(request):
    logout(request)
    return render(request, "Core/Login.html")

def registrar_usuario(request):
    if request.method == "POST":
        nombreUsuario = request.POST.get("v_username")
        claveUsuario = request.POST.get("v_psw")
        correoUsuario = request.POST.get("v_email")

        if User.objects.filter(email=correoUsuario).exists():

            mensaje_error = "El correo ingresado ya está registrado."
            messages.error(request, mensaje_error)
            return render(request, "Core/SignUp.html")

        id_rol_usuario = 2 

        registroIdRol = Rol.objects.get(idRol=id_rol_usuario)
        usuario = Usuario.objects.create(
            nombreUsuario=nombreUsuario,
            correo=correoUsuario,
            clave=claveUsuario,
            idRol=registroIdRol,
        )
        usuario.save()

        user = User.objects.create_user(username=nombreUsuario, password=claveUsuario, email=correoUsuario)
        user.is_active = True
        user.save()

        return redirect("Login")

    return render(request, "Login.html")