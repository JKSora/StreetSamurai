from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth import get_user
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
from .models import *
from django.http import Http404
from django.contrib.auth.models import User

# Create your views here.
def Main(request):
    return render(request,'Core/Main.html')

def Store(request):
    listaP = Producto.objects.all()
    contexto = {"productos": listaP}
    return render(request,'Core/Store.html', contexto)

def AboutUs(request):
    return render(request,'Core/AboutUs.html')

@login_required
def AddItems(request):
    return render(request,'Core/AddItems.html')

@login_required
def ModItems(request):
    return render(request,'Core/ModItems.html')

@login_required
@csrf_exempt
def ALTStore(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        listaP = Producto.objects.all()
        contexto = {"productos": listaP}
        return render(request,'Core/ALTStore.html', contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def modificarP(request, id):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        producto = Producto.objects.get(idProducto=id)
        categoria = Categoria.objects.all()
        contexto = {"datos": producto, "categoria": categoria}
        return render(request, "Core/ModItems.html", contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def eliminarP(request, id):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):    
        producto = Producto.objects.get(idProducto=id)
        producto.delete()
        messages.success(request, "Producto eliminado correctamente")
        return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def agregar(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        categoria = Categoria.objects.all()
        contexto = {"listaCategoria": categoria}
        return render(request, "Core/AddItems.html", contexto)
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def insertarProducto(request):
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        nombreP = request.POST["name"]
        descripcionP = request.POST["description"]
        fotoP = request.FILES["foto"]
        precioP = request.POST["price"]
        stockP = request.POST["cuantity"]
        categoriaP = request.POST["category"]

        registroCategoria = Categoria.objects.get(idCategoria=categoriaP)
        Producto.objects.create(
            nombreProducto=nombreP,
            descripcionProducto=descripcionP,
            imagenProducto=fotoP,
            precioProducto=precioP,
            cantidadProducto=stockP,
            idCategoria=registroCategoria,
        )
        return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")
    
@login_required
def actualizarP(request):
    idP = request.POST.get("idp")
    if request.user.is_superuser or (isinstance(request.user, Usuario) and request.user.idRol.nombreRol == "admin"):
        if idP:
            producto = Producto.objects.get(idProducto=idP)
            nombreP = request.POST.get("name")
            descripcionP = request.POST.get("description")
            precioP = request.POST.get("price")
            stockP = request.POST.get("cuantity")
            categoriaP = request.POST.get("category")

            if request.FILES.get('foto'):
                producto.imagenProducto = request.FILES.get('foto')
            else:
                producto.imagenProducto = producto.imagenProducto  # type: ignore

            producto.nombreProducto = nombreP
            producto.descripcionProducto = descripcionP
            producto.precioProducto = precioP
            producto.cantidadProducto = stockP
            registroCategoria = Categoria.objects.get(idCategoria=categoriaP)
            producto.idCategoria = registroCategoria
            producto.save()
            messages.success(request, "Producto modificado correctamente")
            return redirect("ALTStore")

        else:
            messages.error(request, "No se proporcionó un ID de producto válido")
            return redirect("ALTStore")
    else:
        return HttpResponse("No tienes permiso para acceder a esta página.")

def ContactUs(request):
    return render(request,'Core/ContactUs.html')

def ForgotPassword(request):
    return render(request,'Core/ForgotPassword.html')

def Hoodie(request):
    return render(request,'Core/Hoodie.html')

def Hoodie2(request):
    return render(request,'Core/Hoodie2.html')

def HTSneakers(request):
    return render(request,'Core/HTSneakers.html')

def Login(request):
    return render(request,'Core/Login.html')

@login_required
def ProfileSettings(request):
    return render(request,'Core/ProfileSettings.html')

@login_required
def PurchaseStatus(request):
    return render(request,'Core/PurchaseStatus.html')

def ShoppingCart(request):
    return render(request,'Core/ShoppingCart.html')

def ShoppingCartFULL(request):
    return render(request,'Core/ShoppingCartFULL.html')

def SignUp(request):
    return render(request,'Core/SignUp.html')

def StreetwearPants(request):
    return render(request,'Core/StreetwearPants.html')

def TermsofService(request):
    return render(request,'Core/TermsofService.html')

def iniciar_sesion(request):
    usuario1 = request.POST["email"]
    contra1 = request.POST["psw"]
    try:
        user1 = User.objects.get(username=usuario1)
    except User.DoesNotExist:
        messages.error(request, "El usuario o la contraseña son incorrectos")
        return redirect("Login")
    pass_valida = check_password(contra1, user1.password)
    if not pass_valida:
        messages.error(request, "El usuario o la contraseña son incorrectos")
        return redirect("Login")
    usuario2 = Usuario.objects.get(correoUsuario=usuario1, claveUsuario=contra1)
    user = authenticate(username=usuario1, password=contra1)
    if user is not None:
        login(request, user)
        if usuario2.idRol == 1:
            return redirect("ALTStore")
        else:
            contexto = {"Usuario": usuario2}
            return render(request, "Core/Main.html", contexto)

def cerrar_sesion(request):
    logout(request)
    return render(request, "Core/Login.html")

def registrar_usuario(request):
    if request.method == "POST":
        nombreUsuario = request.POST.get("username")
        claveUsuario = request.POST.get("psw")
        correoUsuario = request.POST.get("email")

        if User.objects.filter(email=correoUsuario).exists():

            mensaje_error = "El correo ingresado ya está registrado."
            messages.error(request, mensaje_error)
            return render(request, "Core/SignUp.html")

        id_rol_usuario = 2 

        registroIdRol = Rol.objects.get(idRol=id_rol_usuario)
        usuario = Usuario.objects.create(
            nombreUsuario=nombreUsuario,
            correoUsuario=correoUsuario,
            claveUsuario=claveUsuario,
            idRol=registroIdRol,
        )
        usuario.save()

        user = User.objects.create_user(username=nombreUsuario, password=claveUsuario, email=correoUsuario)
        user.is_active = True
        user.save()

        return redirect("Login")

    return render(request, "Login.html")

def actualizarPerfilUsuario(request):
    idU = request.POST.get("idu")
    if request.method == "POST":
        if idU:
            Usuario.objects.get(idUsuario=idU)
            nombreC = request.POST["nombre"]
            apellidoC = request.POST["apellido"]
            telefonoC = request.POST["telefono"]
            direccionC = request.POST["direccion"]
            postalC = request.POST["postal"]
            paisC = request.POST["pais"]
            regionC = request.POST["region"]

            cuenta = get_object_or_404(Usuario, idUsuario=idU)

            Usuario.nombreUsuario = nombreC
            Usuario.apellidoPerfil = apellidoC
            Usuario.numeroPerfil = telefonoC
            Usuario.calleDireccion = direccionC
            Usuario.codigoPostal = postalC
            Usuario.paisDireccion = paisC
            Usuario.nombreRegion = regionC
            cuenta.save()
            messages.success(request, "Perfil modificado correctamente")
        else:
            messages.error(request, "No se proporcionó un ID de producto válido")
            return redirect("Main")
    return redirect('Perfil', id=Usuario.idUsuario)

def Perfil(request, id):
    usuario = get_object_or_404(Usuario, idUsuario=id)
    return render(request, 'Core/ProfileSettings.html', {'Usuario': usuario})

def transaction(request):
    total = 0
    transactions = Carrito.objects.all()
    for t in transactions:
        total += t.total_price()
    context = { 'Carrito': transactions, 'total_price': total }
    return render(request, 'Core/ShoppingCartFULL.html', context)