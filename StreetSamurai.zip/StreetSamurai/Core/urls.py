from django.contrib import admin
from django.urls import path, include
from .views import *
from . import views

urlpatterns = [
    path('',Main,name="Main"),
    path('Perfil/<int:id>/', views.Perfil, name='Perfil'),
    path('Store/',Store,name="Store"),
    path('AboutUs/',AboutUs,name="AboutUs"),
    path('AddItems/',AddItems,name="AddItems"),
    path('ModItems/',ModItems,name="ModItems"),
    path('ALTStore/',ALTStore,name="ALTStore"),
    path('ContactUs/',ContactUs,name="ContactUs"),
    path('ForgotPassword/',ForgotPassword,name="ForgotPassword"),
    path('Hoodie/',Hoodie,name="Hoodie"),
    path('Hoodie2/',Hoodie2,name="Hoodie2"),
    path('HTSneakers/',HTSneakers,name="HTSneakers"),
    path('Login/',Login,name="Login"),
    path('ProfileSettings/<id>',ProfileSettings,name="ProfileSettings"),
    path('PurchaseStatus/',PurchaseStatus,name="PurchaseStatus"),
    path('ShoppingCart/',ShoppingCart,name="ShoppingCart"),
    path('ShoppingCartFULL/',ShoppingCartFULL,name="ShoppingCartFULL"),
    path('SignUp/',SignUp,name="SignUp"),
    path('StreetwearPants/',StreetwearPants,name="StreetwearPants"),
    path('TermsofService/',TermsofService,name="TermsofService"),
    path('modificarP/<id>', modificarP, name="modificarP"),
    path('eliminarP/<id>', eliminarP, name="eliminarP"),
    path('agregar/',agregar,name="agregar"),
    path('insertarProducto/', insertarProducto, name="insertarProducto"),
    path('actualizarP/', actualizarP, name="actualizarP"),
    path('iniciar_sesion/', views.iniciar_sesion, name='iniciar_sesion'), # type: ignore
    path('logout/',cerrar_sesion,name="cerrar_sesion"),
    path('registrar_usuario/', views.registrar_usuario, name='registrar_usuario'),
    path('actualizarPerfilUsuario/', views.actualizarPerfilUsuario, name='actualizarPerfilUsuario'),
]