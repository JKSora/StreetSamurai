const COMMENTS_URL = "https://jsonplaceholder.typicode.com/comments";
const MAX_COMMENTS = 10;

async function getComments() {
  const response = await fetch(COMMENTS_URL);
  const comments = await response.json();
  return comments;
}

async function addComment(comment) {
  const response = await fetch(COMMENTS_URL, {
    method: "POST",
    body: JSON.stringify(comment),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  });
  const newComment = await response.json();
  return newComment;
}

function addCommentToList(comment) {
  const commentsContainer = document.getElementById("comments-container");

  const commentElement = document.createElement("div");
  commentElement.classList.add("comment");

  const nameElement = document.createElement("div");
  nameElement.classList.add("name");
  nameElement.textContent = comment.name;

  const bodyElement = document.createElement("div");
  bodyElement.classList.add("body");
  bodyElement.textContent = comment.body;

  commentElement.appendChild(nameElement);
  commentElement.appendChild(bodyElement);

  commentsContainer.insertBefore(commentElement, commentsContainer.firstChild);

  if (commentsContainer.children.length > MAX_COMMENTS) {
    commentsContainer.lastChild.remove();
  }
}

async function showComments() {
  const comments = await getComments();

  comments.forEach((comment) => {
    addCommentToList(comment);
  });
}

const commentForm = document.getElementById("comment-form");
commentForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const comment = document.getElementById("comment").value;

  const newComment = await addComment({ name, body: comment });

  addCommentToList(newComment);

  commentForm.reset();
});

showComments();
