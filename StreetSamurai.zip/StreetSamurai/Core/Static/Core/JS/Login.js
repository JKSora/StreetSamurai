const email = document.getElementById("email");
const password = document.getElementById("psw");
const form = document.getElementById("form");
const listInputs = document.querySelectorAll(".form-input");

form.addEventListener("submit", (e) => {
  let condicion = validacionForm();
  if (condicion) {
    enviarFormulario();
  }
});

function validarContrasena(contrasena) {
  const regex =
    /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?]).{5,18}$/;

  if (!regex.test(contrasena)) {
    const errores = {};
    if (!/(?=.*\d)/.test(contrasena)) {
      errores.numero = "La contraseña no es valida";
    }
    if (!/(?=.*[a-z])/.test(contrasena)) {
      errores.minuscula = "La contraseña no es valida";
    }
    if (!/(?=.*[A-Z])/.test(contrasena)) {
      errores.mayuscula = "La contraseña no es valida";
    }
    if (!/(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?])/.test(contrasena)) {
      errores.especial = "La contraseña no es valida";
    }
    if (contrasena.length < 5 || contrasena.length > 18) {
      errores.longitud = "La contraseña no es valida";
    }
    return errores;
  }
  return true;
}

function validacionForm() {
  form.lastElementChild.innerHTML = " ";
  let condicion = true;
  listInputs.forEach((element) => {
    element.lastElementChild.innerHTML = "";
  });

  if (email.value.length < 1 || email.value.trim() == "") {
    mostrarMensajeError("email", "Ingrese un correo valido");
    condicion = false;
  }

  const errores = validarContrasena(password.value);
  if (errores !== true) {
    if (errores.numero) {
      mostrarMensajeError("psw", errores.numero);
    }
    if (errores.minuscula) {
      mostrarMensajeError("psw", errores.minuscula);
    }
    if (errores.mayuscula) {
      mostrarMensajeError("psw", errores.mayuscula);
    }
    if (errores.especial) {
      mostrarMensajeError("psw", errores.especial);
    }
    if (errores.longitud) {
      mostrarMensajeError("psw", errores.longitud);
    }
    condicion = false;
  }

  return condicion;
}

function mostrarMensajeError(claseInput, mensaje) {
  let elemento = document.querySelector(`.${claseInput}`);
  elemento.lastElementChild.innerHTML = mensaje;
}

function enviarFormulario() {
  form.reset();
  form.lastElementChild.innerHTML = "Inicio de sesión exitoso";
}
