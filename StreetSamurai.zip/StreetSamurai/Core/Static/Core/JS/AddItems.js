const form = document.querySelector("form");
const nameInput = document.querySelector("#v_name");
const descriptionInput = document.querySelector("#v_description");
const priceInput = document.querySelector("#v_price");
const quantityInput = document.querySelector("#v_cuantity");
const categoryInput = document.querySelector("#v_category");
const imageInput = document.querySelector("#v_image");

let currentMessage = null;

form.addEventListener("submit", (event) => {
  let errors = [];

  if (nameInput.value.trim().length < 3) {
    event.preventDefault();
    errors.push("El nombre debe tener al menos 3 caracteres");
    nameInput.classList.add("is-invalid");
  } else {
    nameInput.classList.remove("is-invalid");
  }

  if (descriptionInput.value.trim().length < 3) {
    event.preventDefault();
    errors.push("La descripción debe tener al menos 3 caracteres");
    descriptionInput.classList.add("is-invalid");
  } else {
    descriptionInput.classList.remove("is-invalid");
  }

  if (priceInput.value < 1) {
    event.preventDefault();
    errors.push("El precio debe ser mayor a 0");
    priceInput.classList.add("is-invalid");
  } else {
    priceInput.classList.remove("is-invalid");
  }

  if (quantityInput.value < 0) {
    event.preventDefault();
    errors.push("La cantidad debe ser mayor o igual a 0");
    quantityInput.classList.add("is-invalid");
  } else {
    quantityInput.classList.remove("is-invalid");
  }

  if (categoryInput.value === "") {
    event.preventDefault();
    errors.push("Debe seleccionar una categoría");
    categoryInput.classList.add("is-invalid");
  } else {
    categoryInput.classList.remove("is-invalid");
  }

  if (imageInput.files.length === 0) {
    event.preventDefault();
    errors.push("Debe subir una imagen");
    imageInput.classList.add("is-invalid");
  } else {
    imageInput.classList.remove("is-invalid");
  }

  if (errors.length > 0) {
    event.preventDefault();
    const errorDiv = document.createElement("div");
    errorDiv.classList.add("alert", "alert-danger");
    errorDiv.textContent = `Error: ${errors.join(", ")}`;

    if (currentMessage) {
      event.preventDefault();
      currentMessage.replaceWith(errorDiv);
    } else {
      form.insertBefore(errorDiv, form.firstChild);
    }

    currentMessage = errorDiv;

    setTimeout(() => {
      errorDiv.remove();
      currentMessage = null;
    }, 3000);
  } else {
    const successDiv = document.createElement("div");
    successDiv.classList.add("alert", "alert-success");
    successDiv.textContent = "Producto añadido";

    if (currentMessage) {
      event.preventDefault();
      currentMessage.replaceWith(successDiv);
    } else {
      form.insertBefore(successDiv, form.firstChild);
    }

    currentMessage = successDiv;

    nameInput.value = "";
    descriptionInput.value = "";
    priceInput.value = "";
    quantityInput.value = "";
    categoryInput.value = "";
    imageInput.value = "";

    setTimeout(() => {
      successDiv.remove();
      currentMessage = null;
    }, 3000);
  }
});
