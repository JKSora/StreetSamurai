const email = document.getElementById("v_email");
const password = document.getElementById("v_psw");
const username = document.getElementById("v_username");
const passwordrepeat = document.getElementById("v_pswrepeat");
const terminosYcondiciones = document.getElementById("termsAndConditions");
const form = document.getElementById("form");
const listInputs = document.querySelectorAll(".form-input");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  let condicion = validacionForm();
  if (condicion) {
    enviarFormulario();
  }
});

function validarUsername(username) {
  if (username.length >= 3) {
    return true;
  } else {
    return false;
  }
}

function validarContrasena(contrasena) {
  const regex =
    /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?]).{5,18}$/;

  if (!regex.test(contrasena)) {
    const errores = {};
    if (!/(?=.*\d)/.test(contrasena)) {
      errores.numero = "La contraseña debe tener al menos un número";
    }
    if (!/(?=.*[a-z])/.test(contrasena)) {
      errores.minuscula =
        "La contraseña debe tener al menos una letra minúscula";
    }
    if (!/(?=.*[A-Z])/.test(contrasena)) {
      errores.mayuscula =
        "La contraseña debe tener al menos una letra mayúscula";
    }
    if (!/(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?])/.test(contrasena)) {
      errores.especial =
        "La contraseña debe tener al menos un caracter especial";
    }
    if (contrasena.length < 5 || contrasena.length > 18) {
      errores.longitud =
        "La contraseña debe tener un mínimo de 5 caracteres y un máximo de 18";
    }
    return errores;
  }

  var contrasena = document.getElementById("v_psw").value;
  var contrasenaRepetida = document.getElementById("v_pswrepeat").value;

  if (contrasena != contrasenaRepetida) {
    mostrarMensajeError("v_pswrepeat", "Las contraseñas no coinciden");
    return false;
  }

  return true;
}

function validacionForm() {
  form.lastElementChild.innerHTML = " ";
  let condicion = true;
  listInputs.forEach((element) => {
    element.lastElementChild.innerHTML = "";
  });

  if (email.value.length < 1 || email.value.trim() == "") {
    mostrarMensajeError("v_email", "Ingrese un correo valido");
    condicion = false;
  }

  const errores = validarContrasena(password.value);
  if (errores !== true) {
    if (errores.numero) {
      mostrarMensajeError("v_psw", errores.numero);
    }
    if (errores.minuscula) {
      mostrarMensajeError("v_psw", errores.minuscula);
    }
    if (errores.mayuscula) {
      mostrarMensajeError("v_psw", errores.mayuscula);
    }
    if (errores.especial) {
      mostrarMensajeError("v_psw", errores.especial);
    }
    if (errores.longitud) {
      mostrarMensajeError("v_psw", errores.longitud);
    }
    condicion = false;
  }

  if (!terminosYcondiciones.checked) {
    mostrarMensajeError(
      "termsAndConditions",
      "Por favor, Acepte los términos y condiciones"
    );
    condicion = false;
  } else {
    mostrarMensajeError("termsAndConditions", "");
  }

  return condicion;
}

function mostrarMensajeError(claseInput, mensaje) {
  let elemento = document.querySelector(`.${claseInput}`);
  elemento.lastElementChild.innerHTML = mensaje;
}

function enviarFormulario() {
  form.reset();
  form.lastElementChild.innerHTML = "Registrado Correctamente";
}
