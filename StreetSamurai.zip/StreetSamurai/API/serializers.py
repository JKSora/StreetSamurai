from rest_framework import serializers
from Core.models import Producto, Categoria

class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = ['idProducto','nombreProducto','precioProducto','cantidadProducto','descripcionProducto','idCategoria']
class CategoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Categoria
        fields =['idCategoria','nombreCategoria']