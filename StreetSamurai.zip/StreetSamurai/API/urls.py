from django.contrib import admin
from django.urls import path, include
from API.views import *
from API.viewslogin import *

urlpatterns = [
    path('lista_productos/',lista_productos,name='lista_productos'),
    path('lista_categoria/', lista_categoria, name="lista_categoria"),
    path('detalle_productos/<id>',detalle_productos,name='detalle_productos'),
    path('login', login, name="login"),
]